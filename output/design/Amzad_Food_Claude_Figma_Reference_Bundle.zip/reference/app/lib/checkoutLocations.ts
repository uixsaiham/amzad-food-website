// District/upazila names: https://github.com/nuhil/bangladesh-geocode (MIT).
// City neighbourhoods can use Other area / Thana and supply the full address.
export const districtAreas: Record<string, string[]> = {
  "Bagerhat": [
    "Bagerhat Sadar",
    "Chitalmari",
    "Fakirhat",
    "Kachua",
    "Mollahat",
    "Mongla",
    "Morrelganj",
    "Rampal",
    "Sarankhola"
  ],
  "Bandarban": [
    "Alikadam",
    "Bandarban Sadar",
    "Lama",
    "Naikhongchhari",
    "Rowangchhari",
    "Ruma",
    "Thanchi"
  ],
  "Barguna": [
    "Amtali",
    "Bamna",
    "Barguna Sadar",
    "Betagi",
    "Pathorghata",
    "Taltali"
  ],
  "Barishal": [
    "Agailjhara",
    "Babuganj",
    "Bakerganj",
    "Banaripara",
    "Barisal Sadar",
    "Gournadi",
    "Hizla",
    "Mehendiganj",
    "Muladi",
    "Wazirpur"
  ],
  "Bhola": [
    "Bhola Sadar",
    "Borhan Sddin",
    "Charfesson",
    "Doulatkhan",
    "Lalmohan",
    "Monpura",
    "Tazumuddin"
  ],
  "Bogura": [
    "Adamdighi",
    "Bogra Sadar",
    "Dhunot",
    "Dupchanchia",
    "Gabtali",
    "Kahaloo",
    "Nondigram",
    "Shajahanpur",
    "Shariakandi",
    "Sherpur",
    "Shibganj",
    "Sonatala"
  ],
  "Brahmanbaria": [
    "Akhaura",
    "Ashuganj",
    "Bancharampur",
    "Bijoynagar",
    "Brahmanbaria Sadar",
    "Kasba",
    "Nabinagar",
    "Nasirnagar",
    "Sarail"
  ],
  "Chandpur": [
    "Chandpur Sadar",
    "Faridgonj",
    "Haimchar",
    "Hajiganj",
    "Kachua",
    "Matlab North",
    "Matlab South",
    "Shahrasti"
  ],
  "Chapainawabganj": [
    "Bholahat",
    "Chapainawabganj Sadar",
    "Gomostapur",
    "Nachol",
    "Shibganj"
  ],
  "Chattogram": [
    "Anwara",
    "Banshkhali",
    "Boalkhali",
    "Chandanaish",
    "Fatikchhari",
    "Hathazari",
    "Karnafuli",
    "Lohagara",
    "Mirsharai",
    "Patiya",
    "Rangunia",
    "Raozan",
    "Sandwip",
    "Satkania",
    "Sitakunda"
  ],
  "Chuadanga": [
    "Alamdanga",
    "Chuadanga Sadar",
    "Damurhuda",
    "Jibannagar"
  ],
  "Cox's Bazar": [
    "Chakaria",
    "Coxsbazar Sadar",
    "Eidgaon",
    "Kutubdia",
    "Moheshkhali",
    "Pekua",
    "Ramu",
    "Teknaf",
    "Ukhiya"
  ],
  "Cumilla": [
    "Barura",
    "Brahmanpara",
    "Burichang",
    "Chandina",
    "Chauddagram",
    "Comilla Sadar",
    "Daudkandi",
    "Debidwar",
    "Homna",
    "Laksam",
    "Lalmai",
    "Meghna",
    "Monohargonj",
    "Muradnagar",
    "Nangalkot",
    "Sadarsouth",
    "Titas"
  ],
  "Dhaka": [
    "Dhamrai",
    "Dohar",
    "Keraniganj",
    "Nawabganj",
    "Savar"
  ],
  "Dinajpur": [
    "Birampur",
    "Birganj",
    "Birol",
    "Bochaganj",
    "Chirirbandar",
    "Dinajpur Sadar",
    "Fulbari",
    "Ghoraghat",
    "Hakimpur",
    "Kaharol",
    "Khansama",
    "Nawabganj",
    "Parbatipur"
  ],
  "Faridpur": [
    "Alfadanga",
    "Bhanga",
    "Boalmari",
    "Charbhadrasan",
    "Faridpur Sadar",
    "Madhukhali",
    "Nagarkanda",
    "Sadarpur",
    "Saltha"
  ],
  "Feni": [
    "Chhagalnaiya",
    "Daganbhuiyan",
    "Feni Sadar",
    "Fulgazi",
    "Parshuram",
    "Sonagazi"
  ],
  "Gaibandha": [
    "Gaibandha Sadar",
    "Gobindaganj",
    "Palashbari",
    "Phulchari",
    "Sadullapur",
    "Saghata",
    "Sundarganj"
  ],
  "Gazipur": [
    "Gazipur Sadar",
    "Kaliakair",
    "Kaliganj",
    "Kapasia",
    "Sreepur"
  ],
  "Gopalganj": [
    "Gopalganj Sadar",
    "Kashiani",
    "Kotalipara",
    "Muksudpur",
    "Tungipara"
  ],
  "Habiganj": [
    "Ajmiriganj",
    "Bahubal",
    "Baniachong",
    "Chunarughat",
    "Habiganj Sadar",
    "Lakhai",
    "Madhabpur",
    "Nabiganj"
  ],
  "Jamalpur": [
    "Bokshiganj",
    "Dewangonj",
    "Islampur",
    "Jamalpur Sadar",
    "Madarganj",
    "Melandah",
    "Sarishabari"
  ],
  "Jashore": [
    "Abhaynagar",
    "Bagherpara",
    "Chougachha",
    "Jessore Sadar",
    "Jhikargacha",
    "Keshabpur",
    "Manirampur",
    "Sharsha"
  ],
  "Jhalokati": [
    "Jhalakathi Sadar",
    "Kathalia",
    "Nalchity",
    "Rajapur"
  ],
  "Jhenaidah": [
    "Harinakundu",
    "Jhenaidah Sadar",
    "Kaliganj",
    "Kotchandpur",
    "Moheshpur",
    "Shailkupa"
  ],
  "Joypurhat": [
    "Akkelpur",
    "Joypurhat Sadar",
    "Kalai",
    "Khetlal",
    "Panchbibi"
  ],
  "Khagrachhari": [
    "Dighinala",
    "Guimara",
    "Khagrachhari Sadar",
    "Laxmichhari",
    "Manikchari",
    "Matiranga",
    "Mohalchari",
    "Panchari",
    "Ramgarh"
  ],
  "Khulna": [
    "Botiaghata",
    "Dakop",
    "Digholia",
    "Dumuria",
    "Fultola",
    "Koyra",
    "Paikgasa",
    "Rupsha",
    "Terokhada"
  ],
  "Kishoreganj": [
    "Austagram",
    "Bajitpur",
    "Bhairab",
    "Hossainpur",
    "Itna",
    "Karimgonj",
    "Katiadi",
    "Kishoreganj Sadar",
    "Kuliarchar",
    "Mithamoin",
    "Nikli",
    "Pakundia",
    "Tarail"
  ],
  "Kurigram": [
    "Bhurungamari",
    "Charrajibpur",
    "Chilmari",
    "Kurigram Sadar",
    "Nageshwari",
    "Phulbari",
    "Rajarhat",
    "Rowmari",
    "Ulipur"
  ],
  "Kushtia": [
    "Bheramara",
    "Daulatpur",
    "Khoksa",
    "Kumarkhali",
    "Kushtia Sadar",
    "Mirpur"
  ],
  "Lakshmipur": [
    "Kamalnagar",
    "Lakshmipur Sadar",
    "Raipur",
    "Ramganj",
    "Ramgati"
  ],
  "Lalmonirhat": [
    "Aditmari",
    "Hatibandha",
    "Kaliganj",
    "Lalmonirhat Sadar",
    "Patgram"
  ],
  "Madaripur": [
    "Dasar",
    "Kalkini",
    "Madaripur Sadar",
    "Rajoir",
    "Shibchar"
  ],
  "Magura": [
    "Magura Sadar",
    "Mohammadpur",
    "Shalikha",
    "Sreepur"
  ],
  "Manikganj": [
    "Doulatpur",
    "Gior",
    "Harirampur",
    "Manikganj Sadar",
    "Saturia",
    "Shibaloy",
    "Singiar"
  ],
  "Meherpur": [
    "Gangni",
    "Meherpur Sadar",
    "Mujibnagar"
  ],
  "Moulvibazar": [
    "Barlekha",
    "Juri",
    "Kamolganj",
    "Kulaura",
    "Moulvibazar Sadar",
    "Rajnagar",
    "Sreemangal"
  ],
  "Munshiganj": [
    "Gajaria",
    "Louhajanj",
    "Munshiganj Sadar",
    "Sirajdikhan",
    "Sreenagar",
    "Tongibari"
  ],
  "Mymensingh": [
    "Bhaluka",
    "Dhobaura",
    "Fulbaria",
    "Gafargaon",
    "Gouripur",
    "Haluaghat",
    "Iswarganj",
    "Muktagacha",
    "Mymensingh Sadar",
    "Nandail",
    "Phulpur",
    "Tarakanda",
    "Trishal"
  ],
  "Naogaon": [
    "Atrai",
    "Badalgachi",
    "Dhamoirhat",
    "Manda",
    "Mohadevpur",
    "Naogaon Sadar",
    "Niamatpur",
    "Patnitala",
    "Porsha",
    "Raninagar",
    "Sapahar"
  ],
  "Narail": [
    "Kalia",
    "Lohagara",
    "Narail Sadar"
  ],
  "Narayanganj": [
    "Araihazar",
    "Bandar",
    "Narayanganj Sadar",
    "Rupganj",
    "Sonargaon"
  ],
  "Narsingdi": [
    "Belabo",
    "Monohardi",
    "Narsingdi Sadar",
    "Palash",
    "Raipura",
    "Shibpur"
  ],
  "Natore": [
    "Bagatipara",
    "Baraigram",
    "Gurudaspur",
    "Lalpur",
    "Naldanga",
    "Natore Sadar",
    "Singra"
  ],
  "Netrokona": [
    "Atpara",
    "Barhatta",
    "Durgapur",
    "Kalmakanda",
    "Kendua",
    "Khaliajuri",
    "Madan",
    "Mohongonj",
    "Netrokona Sadar",
    "Purbadhala"
  ],
  "Nilphamari": [
    "Dimla",
    "Domar",
    "Jaldhaka",
    "Kishorganj",
    "Nilphamari Sadar",
    "Syedpur"
  ],
  "Noakhali": [
    "Begumganj",
    "Chatkhil",
    "Companiganj",
    "Hatia",
    "Kabirhat",
    "Noakhali Sadar",
    "Senbug",
    "Sonaimori",
    "Subarnachar"
  ],
  "Pabna": [
    "Atghoria",
    "Bera",
    "Bhangura",
    "Chatmohar",
    "Faridpur",
    "Ishurdi",
    "Pabna Sadar",
    "Santhia",
    "Sujanagar"
  ],
  "Panchagarh": [
    "Atwari",
    "Boda",
    "Debiganj",
    "Panchagarh Sadar",
    "Tetulia"
  ],
  "Patuakhali": [
    "Bauphal",
    "Dashmina",
    "Dumki",
    "Galachipa",
    "Kalapara",
    "Mirzaganj",
    "Patuakhali Sadar",
    "Rangabali"
  ],
  "Pirojpur": [
    "Bhandaria",
    "Kawkhali",
    "Mathbaria",
    "Nazirpur",
    "Nesarabad",
    "Pirojpur Sadar",
    "Zianagar"
  ],
  "Rajbari": [
    "Baliakandi",
    "Goalanda",
    "Kalukhali",
    "Pangsa",
    "Rajbari Sadar"
  ],
  "Rajshahi": [
    "Bagha",
    "Bagmara",
    "Charghat",
    "Durgapur",
    "Godagari",
    "Mohonpur",
    "Paba",
    "Puthia",
    "Tanore"
  ],
  "Rangamati": [
    "Baghaichari",
    "Barkal",
    "Belaichari",
    "Juraichari",
    "Kaptai",
    "Kawkhali",
    "Langadu",
    "Naniarchar",
    "Rajasthali",
    "Rangamati Sadar"
  ],
  "Rangpur": [
    "Badargonj",
    "Gangachara",
    "Kaunia",
    "Mithapukur",
    "Pirgacha",
    "Pirgonj",
    "Rangpur Sadar",
    "Taragonj"
  ],
  "Satkhira": [
    "Assasuni",
    "Debhata",
    "Kalaroa",
    "Kaliganj",
    "Satkhira Sadar",
    "Shyamnagar",
    "Tala"
  ],
  "Shariatpur": [
    "Bhedarganj",
    "Damudya",
    "Gosairhat",
    "Naria",
    "Shariatpur Sadar",
    "Zajira"
  ],
  "Sherpur": [
    "Jhenaigati",
    "Nalitabari",
    "Nokla",
    "Sherpur Sadar",
    "Sreebordi"
  ],
  "Sirajganj": [
    "Belkuchi",
    "Chauhali",
    "Kamarkhand",
    "Kazipur",
    "Raigonj",
    "Shahjadpur",
    "Sirajganj Sadar",
    "Tarash",
    "Ullapara"
  ],
  "Sunamganj": [
    "Bishwambarpur",
    "Chhatak",
    "Derai",
    "Dharmapasha",
    "Dowarabazar",
    "Jagannathpur",
    "Jamalganj",
    "Madhyanagar",
    "Shalla",
    "South Sunamganj",
    "Sunamganj Sadar",
    "Tahirpur"
  ],
  "Sylhet": [
    "Balaganj",
    "Beanibazar",
    "Bishwanath",
    "Companiganj",
    "Dakshinsurma",
    "Fenchuganj",
    "Golapganj",
    "Gowainghat",
    "Jaintiapur",
    "Kanaighat",
    "Osmaninagar",
    "Sylhet Sadar",
    "Zakiganj"
  ],
  "Tangail": [
    "Basail",
    "Bhuapur",
    "Delduar",
    "Dhanbari",
    "Ghatail",
    "Gopalpur",
    "Kalihati",
    "Madhupur",
    "Mirzapur",
    "Nagarpur",
    "Sakhipur",
    "Tangail Sadar"
  ],
  "Thakurgaon": [
    "Baliadangi",
    "Haripur",
    "Pirganj",
    "Ranisankail",
    "Thakurgaon Sadar"
  ]
};
export const districts = Object.keys(districtAreas);

"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import Storefront from "../components/Storefront";
import { ArrowLeft, ArrowRight, Banknote, Check, CheckCircle2, ChevronDown, CreditCard, Info, Lock, Minus, PackageCheck, Phone, Plus, ShieldCheck, ShoppingBag, UserRound, Smartphone, Tag, Trash2, Truck, X } from "lucide-react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faCcVisa, faWhatsapp } from "@fortawesome/free-brands-svg-icons";
import { CartItem, loadCart, saveCart } from "../lib/cart";
import { saveOrder } from "../lib/orders";
import AuthModal from "../components/AuthModal";
import { districtAreas, districts } from "../lib/checkoutLocations";
import CartOffer from "../components/CartOffer";
import { DELIVERY_FEE, FREE_DELIVERY_MINIMUM, qualifiesForFreeDelivery } from "../lib/offers";

type Fields = { name: string; phone: string; email: string; address: string; area: string; district: string; notes: string };
type Errors = Partial<Record<keyof Fields, string>>;
type Promo = { label: string; note: string; type: "percent" | "flat" | "shipping"; value: number; min?: number };
type Order = { id: string; items: CartItem[]; subtotal: number; discount: number; deliveryFee: number; total: number; details: Fields; promoCode: string | null; eta: string; placedAt: string };

const emptyFields: Fields = { name: "", phone: "", email: "", address: "", area: "", district: "", notes: "" };
const MAX_QTY = 20;
const WHATSAPP_NUMBER = "8801327406605";

const promoCodes: Record<string, Promo> = {
  WELCOME10: { label: "10% off your order", note: "10% off", type: "percent", value: 10 },
  AMZAD50: { label: "৳50 off your order", note: "৳50 off over ৳500", type: "flat", value: 50, min: 500 },
  FREESHIP: { label: "Free delivery", note: "Automatic on orders ৳1,000+", type: "shipping", value: 0, min: FREE_DELIVERY_MINIMUM },
};



const paymentOptions = [
  { key: "cod", label: "Cash on Delivery", note: "Pay when you receive", icon: Banknote, enabled: true },
  { key: "card", label: "Credit / Visa Card", note: "Coming soon", icon: CreditCard, enabled: false },
  { key: "bkash", label: "bKash", note: "Coming soon", icon: Smartphone, enabled: false },
  { key: "nagad", label: "Nagad", note: "Coming soon", icon: Smartphone, enabled: false },
];

const nextSteps = [
  { icon: Phone, title: "We confirm by phone", note: "Our team calls you to confirm the order and address." },
  { icon: PackageCheck, title: "Packed with care", note: "Your items are quality checked and sealed for freshness." },
  { icon: Truck, title: "Delivered to your door", note: "Pay in cash when the order arrives." },
];

const fieldOrder: (keyof Fields)[] = ["name", "phone", "email", "address", "district", "area"];

/** Two to three delivery days out, skipping Fridays (no courier deliveries). */
function deliveryWindow(from = new Date()) {
  const addDays = (days: number) => {
    const date = new Date(from);
    let added = 0;
    while (added < days) {
      date.setDate(date.getDate() + 1);
      if (date.getDay() !== 5) added += 1;
    }
    return date;
  };
  const format = (date: Date) => date.toLocaleDateString("en-GB", { weekday: "short", day: "numeric", month: "short" });
  return `${format(addDays(2))} – ${format(addDays(3))}`;
}

function validate(fields: Fields): Errors {
  const errors: Errors = {};
  if (fields.name.trim().length < 3) errors.name = "Enter your full name";
  if (!/^(?:\+?88)?01[3-9]\d{8}$/.test(fields.phone.replace(/[\s-]/g, ""))) errors.phone = "Enter a valid mobile number, e.g. +8801712345678";
  if (fields.email.trim() && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(fields.email.trim())) errors.email = "Enter a valid email address";
  if (fields.address.trim().length < 6) errors.address = "Enter your house, road and block details";
  if (!fields.area || ![...(districtAreas[fields.district] ?? []), "Other area / Thana"].includes(fields.area)) errors.area = "Select your area or thana";
  if (!districts.includes(fields.district)) errors.district = "Select your district";
  return errors;
}

function Field({ id, label, error, optional, hint, tooltip, children }: { id: string; label: string; error?: string; optional?: boolean; hint?: string; tooltip?: string; children: React.ReactNode }) {
  return <div className={error ? "co-field has-error" : "co-field"}>
    <div className="co-field-label-row"><label htmlFor={id}>{label}{optional && <em>Optional</em>}</label>{tooltip && <span className="co-info-tooltip"><button type="button" aria-label={`Information about ${label.toLowerCase()}`} aria-describedby={`${id}-tip`}><Info size={14} /></button><span role="tooltip" id={`${id}-tip`}>{tooltip}</span></span>}</div>
    {children}
    {error ? <span className="co-error" role="alert">{error}</span> : hint ? <span className="co-hint">{hint}</span> : null}
  </div>;
}


function Header() {
  return <Storefront headerOnly />;
}

export default function CheckoutPage() {
  const [cart, setCart] = useState<CartItem[]>([]);
  const [fields, setFields] = useState<Fields>(emptyFields);
  const [authMode, setAuthMode] = useState<"signin" | "signup" | null>(null);
  const [errors, setErrors] = useState<Errors>({});
  const [promoInput, setPromoInput] = useState("");
  const [appliedCode, setAppliedCode] = useState<string | null>(null);
  const [promoError, setPromoError] = useState("");
  const [eta, setEta] = useState("");
  const [order, setOrder] = useState<Order | null>(null);
  const [submitError, setSubmitError] = useState("");
  const [summaryOpen, setSummaryOpen] = useState(false);

  useEffect(() => {
    setCart(loadCart());
    const syncCart = () => setCart(loadCart());
    window.addEventListener("amzad-cart-updated", syncCart);
    setEta(deliveryWindow());
    try {
      const saved = localStorage.getItem("af_checkout_fields");
      if (saved) {
        const parsed: unknown = JSON.parse(saved);
        if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) {
          const safe = { ...emptyFields };
          for (const key of Object.keys(emptyFields) as (keyof Fields)[]) {
            const value = (parsed as Record<string, unknown>)[key];
            if (typeof value === "string") safe[key] = value;
          }
          if (![...(districtAreas[safe.district] ?? []), "Other area / Thana"].includes(safe.area)) safe.area = "";
          setFields(safe);
        }
      }
    } catch {}
    return () => window.removeEventListener("amzad-cart-updated", syncCart);
  }, []);

  const updateField = (field: keyof Fields, value: string) => {
    setFields((current) => ({ ...current, [field]: value }));
    if (errors[field]) setErrors((current) => ({ ...current, [field]: undefined }));
  };
  const updateCart = (next: CartItem[]) => { setCart(next); saveCart(next); };
  const changeQty = (name: string, delta: number) => updateCart(cart.map((item) => item.name === name ? { ...item, qty: Math.min(MAX_QTY, item.qty + delta) } : item).filter((item) => item.qty > 0));
  const removeItem = (name: string) => updateCart(cart.filter((item) => item.name !== name));

  const itemCount = cart.reduce((sum, item) => sum + item.qty, 0);
  const subtotal = cart.reduce((sum, item) => sum + item.qty * item.price, 0);
  const promo = appliedCode ? promoCodes[appliedCode] : undefined;
  const promoActive = !!promo && subtotal >= (promo.min ?? 0);
  const discount = promo && promoActive ? (promo.type === "percent" ? Math.round(subtotal * promo.value / 100) : promo.type === "flat" ? Math.min(promo.value, subtotal) : 0) : 0;
  const baseDelivery = cart.length > 0 ? DELIVERY_FEE : 0;
  const deliveryFee = qualifiesForFreeDelivery(subtotal) || (promo && promoActive && promo.type === "shipping") ? 0 : baseDelivery;
  const total = subtotal - discount + deliveryFee;
  const savings = discount + (baseDelivery - deliveryFee);

  const applyPromo = (rawCode: string) => {
    const code = rawCode.trim().toUpperCase();
    if (!code) { setPromoError("Enter a promo code"); return; }
    const match = promoCodes[code];
    if (!match) { setPromoError("This promo code isn't valid"); return; }
    if (subtotal < (match.min ?? 0)) { setPromoError(`Add ৳${(match.min ?? 0) - subtotal} more to use ${code}`); return; }
    setAppliedCode(code);
    setPromoInput("");
    setPromoError("");
  };
  const removePromo = () => { setAppliedCode(null); setPromoError(""); };

  const submit = (event: React.FormEvent) => {
    event.preventDefault();
    if (cart.length === 0) return;
    setSubmitError("");
    const nextErrors = validate(fields);
    setErrors(nextErrors);
    const firstInvalid = fieldOrder.find((field) => nextErrors[field]);
    if (firstInvalid) {
      const element = document.getElementById(`co-${firstInvalid}`);
      element?.scrollIntoView({ behavior: "smooth", block: "center" });
      element?.focus({ preventScroll: true });
      return;
    }
    const placed: Order = {
      id: `AF${crypto.randomUUID().replace(/-/g, "").toUpperCase()}`,
      items: cart, subtotal, discount, deliveryFee, total,
      details: { ...fields, name: fields.name.trim(), phone: fields.phone.trim(), email: fields.email.trim(), address: fields.address.trim(), area: fields.area.trim(), notes: fields.notes.trim() },
      promoCode: promoActive ? appliedCode : null, eta,
      placedAt: new Date().toLocaleString("en-GB", { day: "numeric", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" }),
    };
    const { details } = placed;
    const saved = saveOrder({ id: placed.id, items: cart, total, deliveryFee, name: details.name, phone: details.phone, address: `${details.address}, ${details.area}, ${details.district}`, eta, placedAt: Date.now() });
    if (!saved) { setSubmitError("This preview could not be saved. Your cart is unchanged. Please enable browser storage or contact our team."); return; }
    setOrder(placed);
    updateCart([]);
    try { localStorage.setItem("af_checkout_fields", JSON.stringify(details)); } catch {}
    window.scrollTo({ top: 0 });
  };

  if (order) {
    const { details } = order;
    return <>
      <Header />
      <main className="checkout-page page-width">
        <div className="co-success">
          <div className="co-success-head">
            <span className="co-success-icon"><CheckCircle2 size={40} /></span>
            <h1>Order preview saved</h1>
            <p>Thank you, <strong>{details.name}</strong>. This order preview is saved on this device. Contact our team to request confirmation.</p>
            <span className="co-order-id">Order <b>#{order.id}</b></span>
          </div>

          <div className="co-success-grid">
            <section className="co-card">
              <h2 className="co-card-title">Order details</h2>
              <ul className="co-receipt">{order.items.map((item) => <li key={item.name}>
                <img src={item.image} alt="" />
                <div><strong>{item.name}</strong><span>Qty {item.qty} × ৳{item.price}</span></div>
                <b>৳{item.qty * item.price}</b>
              </li>)}</ul>
              <div className="co-lines">
                <div><span>Subtotal</span><span>৳{order.subtotal}</span></div>
                {order.discount > 0 && <div className="co-discount"><span>Discount ({order.promoCode})</span><span>−৳{order.discount}</span></div>}
                <div><span>Delivery</span><span>{order.deliveryFee === 0 ? "Free" : `৳${order.deliveryFee}`}</span></div>
                <div className="co-total"><span>Total to pay</span><span>৳{order.total}</span></div>
              </div>
              <p className="co-pay-note"><Banknote size={15} /> Cash on Delivery — please keep ৳{order.total} ready.</p>
            </section>

            <div className="co-success-side">
              <section className="co-card">
                <h2 className="co-card-title">Delivery information</h2>
                <dl className="co-details">
                  <div><dt>Deliver to</dt><dd>{details.name}</dd></div>
                  <div><dt>Phone</dt><dd>{details.phone}</dd></div>
                  {details.email && <div><dt>Email</dt><dd>{details.email}</dd></div>}
                  <div><dt>Address</dt><dd>{details.address}, {details.area}, {details.district}</dd></div>
                  {details.notes && <div><dt>Notes</dt><dd>{details.notes}</dd></div>}
                  <div><dt>Placed on</dt><dd>{order.placedAt}</dd></div>
                </dl>

              </section>
              <div className="co-eta"><Truck size={20} aria-hidden="true" /><div><small>Estimated delivery</small><strong>{order.eta || "2–3 business days"}</strong></div></div>
              <Link className="co-secondary" href={`/track-order/?id=${order.id}`}>Track this order <ArrowRight size={14} /></Link>
              <Link className="co-secondary" href="/my-orders/">View my orders <ArrowRight size={14} /></Link>
              <details className="co-next co-next-dropdown">
                <summary><h2 className="co-card-title">What happens next</h2><ChevronDown size={18} aria-hidden="true" /></summary>
                <ol>{nextSteps.map((step, index) => <li key={step.title}><span><step.icon size={18} /></span><div><strong>{index + 1}. {step.title}</strong><p>{step.note}</p></div></li>)}</ol>
              </details>
              <Link className="co-secondary co-continue-shopping" href="/">Continue Shopping <ArrowRight size={14} /></Link>
            </div>
          </div>


        </div>
      </main>
    </>;
  }

  return <>
    <Header />
    <main className="checkout-page page-width">
      <div className="co-title-row">
        <h1>Checkout</h1>
      </div>

      {cart.length > 0 && <section className="co-account-banner" aria-labelledby="checkout-account-title">
        <span className="co-account-icon" aria-hidden="true"><UserRound size={24} /></span>
        <div className="co-account-copy"><h2 id="checkout-account-title">Already part of the family?</h2><p>Sign in or create an account. You can also checkout below as a guest.</p></div>
        <div className="co-account-actions"><button type="button" className="co-account-signin" onClick={() => setAuthMode("signin")}>Sign in <ArrowRight size={15} /></button><button type="button" className="co-account-register" onClick={() => setAuthMode("signup")}>Create account</button></div>
      </section>}

      {cart.length === 0 ? <div className="co-empty">
        <span><ShoppingBag size={34} /></span>
        <h2>Your cart is empty</h2>
        <p>Add some products to your cart and they will show up here.</p>
        <Link className="cta" href="/"><span>Browse products</span><i className="cta-icon"><ShoppingBag size={15} /></i></Link>
      </div> : <div className="co-grid">
        <form className="co-form" id="checkout-form" onSubmit={submit} noValidate>
          {submitError && <p role="alert" className="co-error">{submitError}</p>}
          <section className="co-card">
            <div className="co-card-head"><span className="co-num">1</span><div><h2>Delivery information</h2></div></div>
            <div className="co-row">
              <Field id="co-name" label="Full name" error={errors.name}>
                <input id="co-name" value={fields.name} onChange={(event) => updateField("name", event.target.value)} placeholder="e.g. Rahim Uddin" autoComplete="name" aria-invalid={!!errors.name} />
              </Field>
              <Field id="co-phone" label="Mobile number" error={errors.phone}>
                <div className="co-phone-input"><span>+880</span><input id="co-phone" type="tel" inputMode="numeric" value={fields.phone.replace(/^(?:\+?88)?0/, "")} onChange={(event) => { const digits = event.target.value.replace(/[^0-9]/g, "").replace(/^(?:880|0)/, ""); updateField("phone", digits ? `+880${digits}` : ""); }} placeholder="1XXXXXXXXX" autoComplete="tel-national" aria-label="Mobile number, country code +880" aria-invalid={!!errors.phone} /></div>
              </Field>
            </div>
            <Field id="co-email" label="Email address" optional error={errors.email} hint="For your order receipt">
              <input id="co-email" type="email" value={fields.email} onChange={(event) => updateField("email", event.target.value)} placeholder="you@example.com" autoComplete="email" aria-invalid={!!errors.email} />
            </Field>

            <Field id="co-address" label="Full address" error={errors.address}>
              <textarea id="co-address" value={fields.address} onChange={(event) => updateField("address", event.target.value)} placeholder="House / flat no., road, block, landmark" rows={3} autoComplete="street-address" aria-invalid={!!errors.address} />
            </Field>
            <div className="co-row">
              <Field id="co-district" label="District" error={errors.district}>
                <div className="co-select">
                  <select id="co-district" value={fields.district} onChange={(event) => { updateField("district", event.target.value); updateField("area", ""); }} autoComplete="address-level2" aria-invalid={!!errors.district}>
                    <option value="">Select district</option>
                    {districts.map((district) => <option key={district} value={district}>{district}</option>)}
                  </select>
                  <ChevronDown size={16} />
                </div>
              </Field>
              <Field id="co-area" label="Area / Thana" error={errors.area} hint={fields.area === "Other area / Thana" ? "Include your area / thana in the full address above." : undefined}>
                <div className="co-select">
                  <select id="co-area" value={fields.area} onChange={(event) => updateField("area", event.target.value)} disabled={!fields.district} autoComplete="address-level3" aria-invalid={!!errors.area}>
                    <option value="">{fields.district ? "Select area / thana" : "Select district first"}</option>
                    {(districtAreas[fields.district] ?? []).map(area => <option key={area} value={area}>{area}</option>)}
                    {fields.district && <option value="Other area / Thana">Other area / Thana</option>}
                  </select>
                  <ChevronDown size={16} />
                </div>
              </Field>
            </div>
            <Field id="co-notes" label="Order notes" optional tooltip="Add delivery directions, a landmark or access instructions. Do not include payment or password details.">

              <textarea aria-describedby="co-notes-tip" id="co-notes" value={fields.notes} onChange={(event) => updateField("notes", event.target.value)} placeholder="Anything we should know?" rows={2} maxLength={300} />
            </Field>
          </section>

          <section className="co-card">
            <div className="co-card-head"><span className="co-num">2</span><div><h2>Payment method</h2><p>All transactions are safe and simple.</p></div></div>
            <div className="co-pay-grid" role="radiogroup" aria-label="Payment method">
              {paymentOptions.map((option) => <div key={option.key} role="radio" aria-checked={option.enabled} aria-disabled={!option.enabled} className={option.enabled ? "co-pay active" : "co-pay disabled"}>
                <span className={`co-pay-icon co-pay-icon-${option.key}`}>{option.key === "bkash" || option.key === "nagad" ? <img src={`/amzad-food-website/payments/${option.key}.svg`} alt="" /> : option.key === "card" ? <FontAwesomeIcon icon={faCcVisa} /> : <option.icon size={20} />}</span>
                <div><strong>{option.label}</strong></div>
                {option.enabled && <span className="co-pay-check"><Check size={13} /></span>}
              </div>)}
            </div>
          </section>

          <button className="co-place co-place-desktop cta cta-lg cta-block" type="submit"><span>Order Now · ৳{total}</span><i className="cta-icon"><Lock size={16} /></i></button>
          <p className="co-legal">By placing your order, you agree to be contacted by our team to confirm delivery.</p>
        </form>

        <aside className="co-summary">
          <section className={summaryOpen ? "co-card co-summary-card open" : "co-card co-summary-card"}>
            <h2 className="co-summary-title"><button type="button" className="co-summary-head" onClick={() => setSummaryOpen((open) => !open)} aria-expanded={summaryOpen}>
              <span className="co-summary-name">Order Summary</span>
              <span className="co-summary-count">{itemCount} {itemCount === 1 ? "item" : "items"}</span>
              <span className="co-summary-mobile-total">৳{total}</span>
              <ChevronDown size={18} className="co-summary-chevron" />
            </button></h2>
            <div className="co-summary-body">
            <ul className="co-items">{cart.map((item) => <li key={item.name}>
              <div className="co-item-img"><img src={item.image} alt="" /><b>{item.qty}</b></div>
              <div className="co-item-info">
                <div className="co-item-name-price"><strong>{item.name}</strong><span className="co-item-unit-price">৳{item.price.toLocaleString("en-IN")} each</span></div>
                <div className="co-item-quantity-total"><div className="co-qty">
                  <button type="button" onClick={() => changeQty(item.name, -1)} aria-label={`Decrease ${item.name} quantity`}><Minus size={12} /></button>
                  <b aria-live="polite">{item.qty}</b>
                  <button type="button" onClick={() => changeQty(item.name, 1)} disabled={item.qty >= MAX_QTY} aria-label={`Increase ${item.name} quantity`}><Plus size={12} /></button>
                </div><strong className="co-item-inline-total" aria-live="polite" aria-label={`Total for ${item.name}`}>৳{(item.qty * item.price).toLocaleString("en-IN")}</strong></div>
              </div>
              <div className="co-item-side">
                <button type="button" onClick={() => removeItem(item.name)} aria-label={`Remove ${item.name}`}><Trash2 size={14} /></button>
              </div>
            </li>)}</ul>

            <CartOffer subtotal={subtotal} />

            <div className="co-promo">
              <h3><Tag size={14} /> Promo code</h3>
              {promo && appliedCode ? <div className={promoActive ? "co-promo-applied" : "co-promo-applied inactive"}>
                <span className="co-promo-icon"><Check size={14} /></span>
                <div><strong>{appliedCode}</strong><small>{promoActive ? `${promo.label} applied` : `Spend ৳${promo.min} to use this code — add ৳${(promo.min ?? 0) - subtotal} more`}</small></div>
                <button type="button" onClick={removePromo} aria-label="Remove promo code"><X size={14} /></button>
              </div> : <>
                <div className={promoError ? "co-promo-form has-error" : "co-promo-form"}>
                  <input value={promoInput} onChange={(event) => { setPromoInput(event.target.value); setPromoError(""); }} onKeyDown={(event) => { if (event.key === "Enter") { event.preventDefault(); applyPromo(promoInput); } }} placeholder="Enter code" aria-label="Promo code" aria-invalid={!!promoError} autoCapitalize="characters" spellCheck={false} />
                  <button type="button" onClick={() => applyPromo(promoInput)}>Apply</button>
                </div>
                {promoError && <span className="co-error" role="alert">{promoError}</span>}
                <div className="co-promo-chips">{Object.entries(promoCodes).filter(([, item]) => item.type !== "shipping").map(([code, item]) => <button type="button" key={code} onClick={() => applyPromo(code)} title={`Apply ${code}`}><b>{code}</b><small>{item.note}</small></button>)}</div>
              </>}
            </div>

            <div className="co-lines">
              <div><span>Subtotal</span><span>৳{subtotal}</span></div>
              {discount > 0 && <div className="co-discount"><span>Discount ({appliedCode})</span><span>−৳{discount}</span></div>}
              <div><span>Delivery</span><span>{deliveryFee === 0 ? <><s>৳{baseDelivery}</s> <em>Free</em></> : `৳${deliveryFee}`}</span></div>
              <div className="co-total"><span>Total</span><span>৳{total}</span></div>
            </div>
            {savings > 0 && <p className="co-savings">🎉 You&apos;re saving ৳{savings} on this order</p>}


            </div>
          </section>

          <section className="co-card co-assure">
            <ul>
              <li><ShieldCheck size={17} /><div><strong>100% authentic products</strong><small>Quality checked before packing</small></div></li>

              <li><Banknote size={17} /><div><strong>Pay when you receive</strong><small>Cash on Delivery on every order</small></div></li>
            </ul>
            <div className="co-help">
              <strong>Need help with your order?</strong>
              <div>
                <a href="tel:+8809613824071"><Phone size={14} /> 09613824071</a>
                <a href={`https://wa.me/${WHATSAPP_NUMBER}`} target="_blank" rel="noreferrer"><FontAwesomeIcon icon={faWhatsapp} fontSize={14} /> 01327406605</a>
              </div>
            </div>
          </section>
        </aside>
      </div>}
    </main>

    <AuthModal open={authMode !== null} initialMode={authMode ?? "signin"} onClose={() => setAuthMode(null)} onSignIn={() => setAuthMode(null)} />
    {cart.length > 0 && <div className="co-mobilebar">
      <div><small>Total to pay</small><strong>৳{total}</strong></div>
      <button className="co-place cta" type="submit" form="checkout-form"><span>Order Now</span><i className="cta-icon"><Lock size={15} /></i></button>
    </div>}
  </>;
}

"use client";

import { useRef, useState } from "react";
import { createPortal } from "react-dom";
import { Check, Clock, Minus, Phone, Plus, Truck, X } from "lucide-react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faWhatsapp } from "@fortawesome/free-brands-svg-icons";
import { CartLine } from "../lib/cart";
import { Product, getProductBrand } from "../lib/products";
import ProductGallery from "./ProductGallery";
import { useModalDialog } from "../lib/useModalDialog";
import { DELIVERY_DESCRIPTION } from "../lib/offers";

type QuickViewProduct = Product;
type Details = { bn: string; blurb: string; highlights: string[]; usage: string[]; origin: string; shelfLife: string; storage: string; sold: number };
type Tab = "info" | "usage" | "delivery";

const tabs: { key: Tab; label: string }[] = [{ key: "info", label: "Product Info" }, { key: "usage", label: "How to Use" }, { key: "delivery", label: "Delivery" }];
const honeyUsage = ["Take one teaspoon on an empty stomach each morning.", "Stir into warm (not boiling) water, milk or tea.", "Drizzle over bread, oats, yoghurt or fruit."];
const details: Record<string, Details> = {
  "Wildflower Honey & Black Seed": { bn: "কালোজিরা মধু", blurb: "Raw wildflower honey blended with black seed — a traditional wellness pairing enjoyed in Bangladeshi homes for generations.", highlights: ["Raw wildflower honey, never overheated or diluted", "Infused with premium black seed (kalojira)", "No added sugar, colour or preservatives", "Sealed in a food-grade jar for freshness"], usage: honeyUsage, origin: "Sundarbans & northern Bangladesh", shelfLife: "18 months", storage: "Cool, dry place away from sunlight", sold: 320 },
  "Sundarbans Raw Honey": { bn: "সুন্দরবনের খাঁটি মধু", blurb: "Wild honey collected sustainably from the mangrove forests of the Sundarbans — dark, rich and full of natural flavour.", highlights: ["Harvested by traditional honey collectors", "100% raw, unprocessed and unheated", "Naturally rich in antioxidants", "Lab tested for purity before packing"], usage: honeyUsage, origin: "Sundarbans, Khulna", shelfLife: "24 months", storage: "Room temperature; natural crystallisation is normal", sold: 410 },
  "Organic Black Seed Oil": { bn: "কালোজিরা তেল", blurb: "Cold-pressed from carefully selected black seeds to keep the natural aroma and goodness — for wellness and care.", highlights: ["Cold-pressed, no heat or chemical extraction", "100% pure, no blending with other oils", "Rich, earthy aroma of fresh black seed", "Packed in a dark bottle to protect quality"], usage: ["Take half a teaspoon daily with honey or warm water.", "Massage gently on scalp or skin as a natural moisturiser.", "Store the bottle tightly capped after every use."], origin: "Bangladesh", shelfLife: "12 months", storage: "Cool, dry place away from sunlight", sold: 280 },
  "Premium Black Seed Oil": { bn: "প্রিমিয়াম কালোজিরা তেল", blurb: "Premium cold-pressed black seed oil made from hand-selected seeds for a strong aroma and consistent quality.", highlights: ["Hand-selected black seeds, cold pressed", "No additives, colour or preservatives", "Strong, authentic black seed aroma", "Sealed, tamper-proof packaging"], usage: ["Take half a teaspoon daily with honey or warm water.", "Use a few drops for hair and skin massage.", "Keep the bottle tightly capped after use."], origin: "Bangladesh", shelfLife: "12 months", storage: "Cool, dry place away from sunlight", sold: 240 },
  "Premium Date Syrup": { bn: "খেজুরের সিরাপ", blurb: "A thick, naturally sweet syrup made from ripe dates — a wholesome replacement for refined sugar.", highlights: ["Made from ripe, hand-picked dates", "No refined sugar or artificial sweeteners", "Naturally rich in iron and minerals", "Smooth, thick texture with a caramel-like taste"], usage: ["Pour over pancakes, oats, yoghurt or desserts.", "Stir into milk, smoothies or tea instead of sugar.", "Use as a natural glaze in baking and cooking."], origin: "Jessore, Bangladesh", shelfLife: "12 months", storage: "Cool, dry place; refrigerate after opening", sold: 190 },
  "Pure Ghee": { bn: "খাঁটি ঘি", blurb: "Slow-cooked from fresh cow milk butter in small batches, with the golden colour and rich aroma of traditional ghee.", highlights: ["Made from fresh milk butter, slow cooked", "Golden colour with a rich, nutty aroma", "No vegetable fat or artificial flavour", "High smoke point — great for everyday cooking"], usage: ["Add a spoonful over hot rice, khichuri or polao.", "Use for frying, tempering and making sweets.", "Spread on roti or paratha instead of butter."], origin: "Bangladesh", shelfLife: "12 months", storage: "Airtight container in a cool, dry place", sold: 520 },
  "Puffed Rice": { bn: "মুড়ি", blurb: "Light, crisp and freshly puffed — the classic Bangladeshi snack, packed to stay crunchy.", highlights: ["Freshly puffed from selected rice", "Light, crisp and easy to digest", "No added colour or preservatives", "Resealable packaging keeps it crunchy"], usage: ["Mix with mustard oil, onion, chilli and coriander for jhal muri.", "Enjoy with milk, jaggery or fresh fruit.", "Serve as a light evening snack with tea."], origin: "Bangladesh", shelfLife: "3 months", storage: "Airtight container, away from moisture", sold: 610 },
  "Khejur Gur": { bn: "খেজুরের গুড়", blurb: "Traditional date-palm jaggery made by slow-boiling fresh sap — the taste of winter mornings in the village.", highlights: ["Made from fresh date-palm sap", "No sugar, chemicals or artificial colour", "Deep caramel flavour and natural sweetness", "Perfect for pitha, payesh and sweets"], usage: ["Use in pitha, payesh and traditional sweets.", "Grate over warm rice or roti for a natural sweet bite.", "Melt into warm milk or tea as a sugar substitute."], origin: "Jessore & Satkhira", shelfLife: "6 months", storage: "Airtight container in a cool, dry place", sold: 350 },
  "Mango Pickle": { bn: "আমের আচার", blurb: "Sun-dried green mango slices cured with mustard oil and hand-ground spices, the traditional way.", highlights: ["Made from fresh green mangoes", "Cured in mustard oil with traditional spices", "Perfect balance of tangy, spicy and sweet", "No artificial colour or flavour"], usage: ["Serve a spoonful with rice, khichuri or paratha.", "Use as a side with dal, bhorta or biryani.", "Always use a dry spoon to keep the pickle fresh."], origin: "Rajshahi", shelfLife: "9 months", storage: "Airtight jar; keep away from moisture", sold: 270 },
};
const fallbackDetails: Details = { bn: "আমজাদ ফুড", blurb: "Contact our team for product details before ordering.", highlights: [], usage: ["Follow the product label. Contact our team if you need more information."], origin: "", shelfLife: "", storage: "", sold: 0 };


export default function QuickView({ product, onAdd, onOrderNow, onClose, embedded = false, initialQuantity = 1 }: {
  embedded?: boolean;
  initialQuantity?: number;
  product: QuickViewProduct;
  onAdd: (item: CartLine, qty: number) => void;
  onOrderNow: (item: CartLine, qty: number) => void;
  onClose: () => void;
}) {
  const info = details[product.name] ?? { ...fallbackDetails, bn: product.bn ?? fallbackDetails.bn };
  const dialog = useRef<HTMLDivElement>(null);
  useModalDialog(dialog, !embedded, onClose);
  const [qty, setQty] = useState(initialQuantity);
  const [tab, setTab] = useState<Tab>("info");

  const price = product.price;
  const saving = Math.max(0, (product.oldPrice ?? price) - price);
  const line: CartLine = { name: product.name, price, image: product.image };
  const whatsappText = encodeURIComponent(`Hello Amzad Food, I would like to order ${qty} × ${line.name} (৳${price * qty}).`);
  const infoRows: [string, string][] = [["Brand", getProductBrand(product)], ["Category", product.category], ["Pack", product.unit ?? "Contact us for pack details"]];

  const content = (
    <div className={embedded ? "pd-product" : "qv-backdrop"} onClick={onClose} role="presentation">
      <div ref={dialog} tabIndex={-1} className="qv" role={embedded ? undefined : "dialog"} aria-modal={embedded ? undefined : true} aria-label={`Quick view ${product.name}`} onClick={(event) => event.stopPropagation()}>
        {!embedded && <button className="qv-close" onClick={onClose} aria-label="Close quick view"><X size={18} /></button>}

        <div className="qv-scroll">
        <div className="qv-media">
          {saving > 0 && <span className="qv-save">Save ৳{saving}</span>}
          {product.tag && <span className="qv-tag">{product.tag}</span>}
          <ProductGallery key={product.name} product={product} />
        </div>

        <div className="qv-body">
          <div className="qv-meta"><span className="qv-cat">{product.category}</span></div>
          {embedded ? <h1 className="qv-title"><span>{info.bn}</span>{product.name}</h1> : <h2 className="qv-title"><span>{info.bn}</span>{product.name}</h2>}
          <div className="qv-price"><strong>৳{price}</strong>{saving > 0 && <><del>৳{product.oldPrice}</del><em>You save ৳{saving}</em></>}</div>
          <p className="qv-blurb">{info.blurb}</p>

          <div className="qv-block"><h4>Pack <small>{product.unit ?? "Contact us for pack details"}</small></h4></div>

          <ul className="qv-highlights">{info.highlights.map((item) => <li key={item}><Check size={14} />{item}</li>)}</ul>

          <div className="qv-offer"><Truck size={16} /><span>Cash on Delivery available · Free delivery on orders ৳1,000+</span></div>

          <div className="qv-buy">
            <div className="qv-qty"><button onClick={() => setQty((value) => Math.max(1, value - 1))} aria-label="Decrease quantity" disabled={qty === 1}><Minus size={14} /></button><b aria-live="polite">{qty}</b><button onClick={() => setQty((value) => Math.min(20, value + 1))} aria-label="Increase quantity" disabled={qty === 20}><Plus size={14} /></button></div>
            <strong className="qv-line-total" aria-live="polite">Total: ৳{price * qty}</strong>
            <button className="qv-add cta" onClick={() => { onAdd(line, qty); onClose(); }}><span>Add to Cart · ৳{price * qty}</span></button>
            <button className="qv-order cta cta-dark" onClick={() => { onOrderNow(line, qty); onClose(); }}><span>Order Now</span></button>
          </div>
          <div className="qv-contact">
            <a className="qv-whatsapp" href={`https://wa.me/8801327406605?text=${whatsappText}`} target="_blank" rel="noreferrer" aria-label="Order via WhatsApp 01327406605"><FontAwesomeIcon icon={faWhatsapp} fontSize={15} />01327406605</a>
            <a className="qv-whatsapp qv-call" href="tel:+8809613824071" aria-label="Call 09613824071"><Phone size={14} />09613824071</a>
          </div>

          <div className="qv-tabs" role="tablist" aria-label="Product details">{tabs.map((item) => <button key={item.key} role="tab" aria-selected={tab === item.key} className={tab === item.key ? "active" : ""} onClick={() => setTab(item.key)}>{item.label}</button>)}</div>
          <div className="qv-panel" role="tabpanel">
            {tab === "info" && <dl className="qv-info">{infoRows.map(([label, value]) => <div key={label}><dt>{label}</dt><dd>{value}</dd></div>)}</dl>}
            {tab === "usage" && <ol className="qv-usage">{info.usage.map((step) => <li key={step}>{step}</li>)}</ol>}
            {tab === "delivery" && <ul className="qv-delivery">
              <li><Truck size={15} /><span><b>Delivery time</b>See the estimated delivery window at checkout</span></li>
              <li><Clock size={15} /><span><b>Delivery charge</b>{DELIVERY_DESCRIPTION}</span></li>
              <li><Check size={15} /><span><b>Payment</b>Cash on Delivery — pay when you receive</span></li>
              <li><FontAwesomeIcon icon={faWhatsapp} fontSize={15} /><span><b>Need help?</b>Call 09613824071 or WhatsApp 01327406605</span></li>
            </ul>}
          </div>
        </div>
        </div>
      </div>
    </div>
  );
  return embedded ? content : createPortal(content, document.body);
}
